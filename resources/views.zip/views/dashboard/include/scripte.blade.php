<script src="{{ asset('asset/dashboard/assets/js/jquery.min.js')}}"></script>

<!-- BOOTSTRAP JS -->
<script src="{{ asset('asset/dashboard/assets/plugins/bootstrap/js/popper.min.js')}}"></script>
<script src="{{ asset('asset/dashboard/assets/plugins/bootstrap/js/bootstrap.min.js')}}"></script>

<!-- INPUT MASK JS-->
<script src="{{ asset('asset/dashboard/assets/plugins/input-mask/jquery.mask.min.js')}}"></script>

<!-- SIDE-MENU JS -->
<script src="{{ asset('asset/dashboard/assets/plugins/sidemenu/sidemenu.js')}}"></script>

<!-- TypeHead js -->
<script src="{{ asset('asset/dashboard/assets/plugins/bootstrap5-typehead/autocomplete.js')}}"></script>
<script src="{{ asset('asset/dashboard/assets/js/typehead.js')}}"></script>

<!-- SIDEBAR JS -->
<script src="{{ asset('asset/dashboard/assets/plugins/sidebar/sidebar.js')}}"></script>

<!-- Perfect SCROLLBAR JS-->
<script src="{{ asset('asset/dashboard/assets/plugins/p-scroll/perfect-scrollbar.js')}}"></script>
<script src="{{ asset('asset/dashboard/assets/plugins/p-scroll/pscroll.js')}}"></script>
<script src="{{ asset('asset/dashboard/assets/plugins/p-scroll/pscroll-1.js')}}"></script>

<!-- Color Theme js -->
<script src="{{ asset('asset/dashboard/assets/js/themeColors.js')}}"></script>

<!-- Sticky js -->
<script src="{{ asset('asset/dashboard/assets/js/sticky.js')}}"></script>

<!-- CUSTOM JS -->
<script src="{{ asset('asset/dashboard/assets/js/custom.js')}}"></script>

@stack('script')
